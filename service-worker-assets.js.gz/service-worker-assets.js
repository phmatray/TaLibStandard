self.assetsManifest = {
  "version": "zibWxPg1",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-A8e6zZwhOqf7lDQqbbCYcAUv4wGE9aQxOo4WyYxR//0=",
      "url": "_content/Microsoft.DotNet.HotReload.WebAssembly.Browser/Microsoft.DotNet.HotReload.WebAssembly.Browser.99zm1jdh75.lib.module.js"
    },
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-sS4WgHtIUGh1cBcbl405QqFiytU1q+N+rpjwhH0zLzY=",
      "url": "_framework/Demo.BlazorWasm.th3s2zsbog.wasm"
    },
    {
      "hash": "sha256-aXc07FYYWkqPqDYLiAg4qj9QOG4woLJl7kUG+tyjoHA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.zhtt2rs0yn.wasm"
    },
    {
      "hash": "sha256-DmkfuEBHO/HyXlQWYiZ1fpCZwk6puISzo8mQL6XFfIk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ycmz75y6p4.wasm"
    },
    {
      "hash": "sha256-koE7yuGtR5GGyP4tvb53HiRk7HLNPc4X2ZpEj2CNfQc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.a5n1z4sg6a.wasm"
    },
    {
      "hash": "sha256-XQoI2kdnSBt+eU+InR5jb0FlfYIUUGtJpjWD9Ii2sug=",
      "url": "_framework/Microsoft.AspNetCore.Components.hnpqemmfzs.wasm"
    },
    {
      "hash": "sha256-c1tB08GIbOIai2bA4PgA2IQ6tQSbxkg1YfB8lhzFdh4=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.vdogoxs6cm.wasm"
    },
    {
      "hash": "sha256-DF5ZQPnsimHgu/OhXI14ihBGcEBOY9jXNikZbJl7ouk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gdtptxu0m1.wasm"
    },
    {
      "hash": "sha256-WQurBbuDtkPNdWdC7Lbk07OTfLLaEGN9l68/4BxEU7c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.3ped9ou2lc.wasm"
    },
    {
      "hash": "sha256-W7mtMnscYp8Lm6bOFiNQIzi2jmhPwTSt+p55NOguXJk=",
      "url": "_framework/Microsoft.Extensions.Configuration.rg826fsozh.wasm"
    },
    {
      "hash": "sha256-3xVwdgr2WuNwX5z4BXW9ksfLQBDCWY69O8lbIGoHuLE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.jrwstponlh.wasm"
    },
    {
      "hash": "sha256-rEG3da6BrNUeO3KbBWBg2CeOLGPbwAhaeQkynbC3XMQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.scyrntte5w.wasm"
    },
    {
      "hash": "sha256-PkwLOyrHX2POJ7In/xwUvSjwfdKGqLQI6MU2nA8GVKw=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ae89paw0py.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-Nsz2+qtCImtXpERsiSbThwGZv6Pg2Ni8PunRMFiU+Rg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.aruygbmesc.wasm"
    },
    {
      "hash": "sha256-Qa4/Z0kdUZSeM/AH6VqMRzUW+WiiYzKP4SfIVpkTH3M=",
      "url": "_framework/Microsoft.Extensions.Logging.vgeqi1hit2.wasm"
    },
    {
      "hash": "sha256-cLbU1JoUS71dBj6tI1sf8oMT+SufkXtIfCr06uQvARU=",
      "url": "_framework/Microsoft.Extensions.Options.47n8zfzrqx.wasm"
    },
    {
      "hash": "sha256-H31NJrVFPp2OG96Xx3ncGsD6GKT7dPmJqzg7vrTmgLY=",
      "url": "_framework/Microsoft.Extensions.Primitives.p672mzndxd.wasm"
    },
    {
      "hash": "sha256-4I+0kHd4SomBH7+AYwAomyTpYchOHG0eb6kHl9ZrDTk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.0o8pok1eno.wasm"
    },
    {
      "hash": "sha256-8PHvV6IQxuKucAg5xoFd9jjfLvygleka6qvSFgBOuLk=",
      "url": "_framework/Microsoft.JSInterop.w4ui5wk3mk.wasm"
    },
    {
      "hash": "sha256-k1r96nRY+qGJZv5l4aHDT2Mt4tS0IOENGZhhpDtvcxU=",
      "url": "_framework/MudBlazor.1zwunnngs0.wasm"
    },
    {
      "hash": "sha256-cwWOZaOlWiAEvO+KvJwrGbZmVGU/y9yYgansWdR1DsQ=",
      "url": "_framework/System.73436igil7.wasm"
    },
    {
      "hash": "sha256-Lxyl9xp/K61KHJSTAmAcAtaxRgF8AyBXmswd6oS1y68=",
      "url": "_framework/System.Collections.Concurrent.rptr5yidjr.wasm"
    },
    {
      "hash": "sha256-K++PC16j20wBfECnOcdmJtBimXbkck00oMYvts+sdNs=",
      "url": "_framework/System.Collections.Immutable.z6flbxa0d5.wasm"
    },
    {
      "hash": "sha256-2BHZpxNNtpZa5cKCX5F2JdYz0MQ+I8ACi6gj0hDJMM8=",
      "url": "_framework/System.Collections.s31tbb7g0e.wasm"
    },
    {
      "hash": "sha256-sGAVRVerGr1PXOBJegm0HWHvLCErdf+zxY/WjrKJVbA=",
      "url": "_framework/System.ComponentModel.Annotations.knq7u0s56r.wasm"
    },
    {
      "hash": "sha256-HI3e8UtBGT1zSqq8Rgly9q8g8jjzJA5akj6CffJzsAk=",
      "url": "_framework/System.ComponentModel.Primitives.4yhpydnl9z.wasm"
    },
    {
      "hash": "sha256-nLNv0Fa5zOoRUYuKXIVPlnteAqyL2078kT7LM4ZQGC4=",
      "url": "_framework/System.ComponentModel.TypeConverter.c0tr4xwhq6.wasm"
    },
    {
      "hash": "sha256-vgMb/PhAL6mZxeP1IhCz74r4EypDGJU0+tZ4Sq6EvXI=",
      "url": "_framework/System.ComponentModel.udxh9kg35r.wasm"
    },
    {
      "hash": "sha256-oMJltm76zSoWDLnI7ESRKlcVvx1j/SVxh+lxjwmk3W0=",
      "url": "_framework/System.Console.o2onh6m0u6.wasm"
    },
    {
      "hash": "sha256-itRrbbtGU5aA8QUpWlmY7y9VfLq4LYBON9jeHDHVFSQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.25oxnng4o6.wasm"
    },
    {
      "hash": "sha256-YETgkYsSCpN1j8iN/kykAr/xvo1Wj21YdTdxzCtB1LQ=",
      "url": "_framework/System.IO.Pipelines.4f8vg2rcxi.wasm"
    },
    {
      "hash": "sha256-ejthIRTRemEplkarrrKI9KuGsEme9mJP4F+5LcysHUo=",
      "url": "_framework/System.Linq.Expressions.q80pqd0vt5.wasm"
    },
    {
      "hash": "sha256-+tL6RytRDgr7W4LKlvJ/oGbclofC3UkKdexYrKcC0VQ=",
      "url": "_framework/System.Linq.u22uf2dtdr.wasm"
    },
    {
      "hash": "sha256-981hPKjdPnV4oXNDnR2ysTkzVWtkLIFaUEhuVkLeu8Y=",
      "url": "_framework/System.Memory.vuye6gmb3i.wasm"
    },
    {
      "hash": "sha256-yNFwMJdkBiFI4syRCMnCX0n8amYunoloklzGtVVlaM0=",
      "url": "_framework/System.Net.Http.ga938uwdjx.wasm"
    },
    {
      "hash": "sha256-U/945F1XxZKGrWTdyqD3AHwdsrpR2E/QGiMKW+hd5TU=",
      "url": "_framework/System.Net.Primitives.hv4krs0bew.wasm"
    },
    {
      "hash": "sha256-1OH2T6aBX3Ry9K13I+/kq58lyeDSMgZMFRHkb8JHrc8=",
      "url": "_framework/System.ObjectModel.w1xyey7kvy.wasm"
    },
    {
      "hash": "sha256-QMOU8e190fCPRe7m5i5OVQMc+KrssLG6cRiQfpgpchs=",
      "url": "_framework/System.Private.CoreLib.gso9v6gwpu.wasm"
    },
    {
      "hash": "sha256-UZVWLRd0GpFToGaLAVZpcGGvdYLM034O4Sh5bDvhYDg=",
      "url": "_framework/System.Private.Uri.d1qmgyx6c4.wasm"
    },
    {
      "hash": "sha256-W9ESzMNrB0Cjt1YZL39Yb4daAPwKatQUst9AmVjw0M8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.50ez5m42lb.wasm"
    },
    {
      "hash": "sha256-4AahbVd0BTYOs/bAARMGgsUpKWeV2oSRJWllis9AkAM=",
      "url": "_framework/System.Runtime.InteropServices.kzyvk071y4.wasm"
    },
    {
      "hash": "sha256-Ghod4bQwI889aZaLsla4jxRR5ZXA9V405mAvfvkyfVY=",
      "url": "_framework/System.Runtime.Loader.6xjlyguxe5.wasm"
    },
    {
      "hash": "sha256-xNF9XMUgrj543zVQl5qastejh/Sg/3odX2t76XHeYJg=",
      "url": "_framework/System.Runtime.gx53lzjri3.wasm"
    },
    {
      "hash": "sha256-2moma+Q/JRBY6Q172/lkRsN7/ZJ4sSFm1DFbCKsVvJs=",
      "url": "_framework/System.Security.Cryptography.yyjjz7spvh.wasm"
    },
    {
      "hash": "sha256-g9jz8+ak01cy/0F4enX5tDiWmL2jztVbczmMPtnrxvA=",
      "url": "_framework/System.Text.Encodings.Web.30g2bsoz6f.wasm"
    },
    {
      "hash": "sha256-wUiUQE9p8MACrNgZ+n02Yvnk4Aix6lLQFVcr8GiKjJs=",
      "url": "_framework/System.Text.Json.9ybdrcmrvb.wasm"
    },
    {
      "hash": "sha256-NwSslVSQ6pVdkuiyYkJYKTTlYGof1V38Bui1OsqWYvQ=",
      "url": "_framework/System.Text.RegularExpressions.jhg7p3pqfv.wasm"
    },
    {
      "hash": "sha256-ujyjbUn1EF8r/HMwgmEYQZagWwEWv2gFVmSTOe+wjW8=",
      "url": "_framework/System.Threading.6lo1ejxchd.wasm"
    },
    {
      "hash": "sha256-Tii0QyG/6g0iuont0wZ9eVAQXwqs0uSMCB3W2GafwHc=",
      "url": "_framework/TechnicalAnalysis.Candles.uwfzd43g6j.wasm"
    },
    {
      "hash": "sha256-VrbnYKKpQoFKvlGziWlpFQJGLFpZ6vbq73dk+AAk7Ow=",
      "url": "_framework/TechnicalAnalysis.Common.mwkay7p7ed.wasm"
    },
    {
      "hash": "sha256-/Zxft9Yb//c2MmzjinLM7j5b1OkohBToc6sS4sR7vIo=",
      "url": "_framework/TechnicalAnalysis.Functions.hnb80gve1p.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-nefDsBudWy+uNg5RCso9bxLxHj0Kc8Y3bbVZ7iLE3pY=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-/I3SDHIle7heAxlUGBrgxax+lkKyWyRLBVEJmTHJSCs=",
      "url": "_framework/dotnet.native.cs8mcre4gh.js"
    },
    {
      "hash": "sha256-vjddPOzSD1RO9Een4QrlAPnxzBSmD/QchBKKmBMLZwg=",
      "url": "_framework/dotnet.native.muve7a13r4.wasm"
    },
    {
      "hash": "sha256-jCsbbdXoVd1zzGc0fQT2sz4mKuv0ANdurPVGo5Sc2jg=",
      "url": "_framework/dotnet.runtime.0j6ezsi0n0.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Y0W2BrXA2W+iMOvac3a+G1GlJoK3RmMpJcIbhemqbGU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LIDaGPQuZu8g1QOOr/UUXNrhLfvw0ZYP6z9cVbjIRyI=",
      "url": "index.html"
    },
    {
      "hash": "sha256-R25UNyCpj4CK8yB/1gtqA38W2M/OqKs3G8nLgGIYMAI=",
      "url": "js/d3-charts.js"
    },
    {
      "hash": "sha256-+O7O1LShC0Z2y7DNaVi8W6Nfh+FHVfz3YNr5m2CP9D0=",
      "url": "manifest.json"
    }
  ]
};
