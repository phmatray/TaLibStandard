self.assetsManifest = {
  "version": "odIIki3F",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-7nVKjreqh/mHSdpaJ08hXsxM7Nbun+OcZcEZkUtVhMc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-O2UJyVCl+4RaA/jZS/WQ4tMRIZbpXtfRhr5eVl0xLm8=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-6KgnGw6ahsLzKXPCF3B8dndRny7BWKqpaT8jdbxMAbE=",
      "url": "_framework/Demo.BlazorWasm.k90rpth7s8.wasm"
    },
    {
      "hash": "sha256-/1TfBt/IOdk6vrNxUX8feUS6zNpQcpB7yORLmurmfsE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3fizxrs11t.wasm"
    },
    {
      "hash": "sha256-ex1gffLovjYmyKDbc684c4yjXeI2AflMbcsEq0+ftF0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7l8gi78hmr.wasm"
    },
    {
      "hash": "sha256-emRN3lp6pyAQiza+BhM5+WtNZKLHizh8b6Ogkazmigg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.615skuxmvs.wasm"
    },
    {
      "hash": "sha256-mNXe0hQE/RtIfN4TjV7fObXbWNQK005+irmR6rPJF2o=",
      "url": "_framework/Microsoft.AspNetCore.Components.oc5i69id0o.wasm"
    },
    {
      "hash": "sha256-+52uAIsV+OtrUHyK0+8YzIDXKsn5LIMpLBJczFcAlW0=",
      "url": "_framework/Microsoft.Extensions.Configuration.3irbq5boza.wasm"
    },
    {
      "hash": "sha256-8kkxgl2M6lZepIZpPMKQLV8wcofvOGr5pHj7cft6lNY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.mjz45m49fm.wasm"
    },
    {
      "hash": "sha256-TxOo9nPmVL3U9K4TaX1871k0es8meg5RhQtvn2xXGbc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.x8nc4ezhyo.wasm"
    },
    {
      "hash": "sha256-ZyxRtZeUIy5oEYXtEla0JHVd9hyzCJt3YetQEXeFqsI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.nkc3ejh7yu.wasm"
    },
    {
      "hash": "sha256-5gwu0mYaoqPKE60PdSEdUGhQZoxYbCm0UBH1Hm+hZa8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.iqantsnbh2.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-XpUBMOzXHGtE7JRbM8hjtqBvr8Huf6pxMxvYUh8RLLE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.m2gcl1ad8j.wasm"
    },
    {
      "hash": "sha256-d++3uvri7GMhyWGbCjeyHzOWjuav1kcihRQITVUffMk=",
      "url": "_framework/Microsoft.Extensions.Logging.bjke0ozgr8.wasm"
    },
    {
      "hash": "sha256-B1ciuISTYqpeDGW+h2oXZ1e/4geUIQ2fuR/RNGXatXk=",
      "url": "_framework/Microsoft.Extensions.Options.zttou3yn8o.wasm"
    },
    {
      "hash": "sha256-IuaenpYMh7L1lBxF0ipi4BqLJIarq8zPH49edWgK8H0=",
      "url": "_framework/Microsoft.Extensions.Primitives.ivrbo4p2mr.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-9ra3IxVXwH6rq311rvqMfwzaHH84XEaeNWUpuRp3LYY=",
      "url": "_framework/Microsoft.JSInterop.uf1vcdlwc1.wasm"
    },
    {
      "hash": "sha256-y2ABcm5Mr1MfEGYHeSi28JSMksZkTzAs290D2Dhg7so=",
      "url": "_framework/MudBlazor.jyn6mvbxvd.wasm"
    },
    {
      "hash": "sha256-4ll6S1ExwOD1LmfwiId35To/mI19U0iNOe4IcBJYgNs=",
      "url": "_framework/System.Collections.66ovqgkhvr.wasm"
    },
    {
      "hash": "sha256-Im1LjxR1bxqCHbDmhrHgbaHF02zBLHso9J4J2SZ7miw=",
      "url": "_framework/System.Collections.Concurrent.ybre5rqoh3.wasm"
    },
    {
      "hash": "sha256-DHhmr5IJfXfhMZC+yggFgX8RifPPYcQcsxGA3hjCCC0=",
      "url": "_framework/System.Collections.Immutable.0de5wsyew4.wasm"
    },
    {
      "hash": "sha256-M+QkekpO2jscOB42OaaDHkngPRN8dwMiGfeMv8YtGbg=",
      "url": "_framework/System.ComponentModel.389mgrr0ti.wasm"
    },
    {
      "hash": "sha256-V4xCXKLph98HyUUeODhFfSCGGFvncdOcVaqn74YUaEI=",
      "url": "_framework/System.ComponentModel.Annotations.brcj15zf57.wasm"
    },
    {
      "hash": "sha256-2c+K28LEpPgZxq9yVKqKXmXL5BO1F4rzLVveo0frIno=",
      "url": "_framework/System.ComponentModel.Primitives.lpo3ou27c5.wasm"
    },
    {
      "hash": "sha256-I3suKkVQc2x4iioPVlsFJkuneoPgFcAQV2Fs/p368Xg=",
      "url": "_framework/System.ComponentModel.TypeConverter.re1wwn9pv5.wasm"
    },
    {
      "hash": "sha256-tZuPD2FW9YmPGq7fSMcNVHB+8xS07B1mPhoRo+cAIYM=",
      "url": "_framework/System.Console.zqcrf7cto2.wasm"
    },
    {
      "hash": "sha256-009Ea/OayQfi1jSIMjESOkkLX5b5T0673COc6qa+1UI=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.p991bg6tj7.wasm"
    },
    {
      "hash": "sha256-0uljQYkN7r22Bww1ENZAVGTupoPwfKICKYE7IbIfkLU=",
      "url": "_framework/System.IO.Pipelines.ij3x2x6ncl.wasm"
    },
    {
      "hash": "sha256-uVVnRmd77kwPCY1z7mVgrZ1Q0N+KnM0qv/rnj5SGpm8=",
      "url": "_framework/System.Linq.Expressions.55gomq7kz1.wasm"
    },
    {
      "hash": "sha256-cqF/Fjrgy7W3uXvoFDcaJS93/EE7MCQLjJbjvb9f1Yo=",
      "url": "_framework/System.Linq.uc0jyd2w3i.wasm"
    },
    {
      "hash": "sha256-kc8nGU1sKOWWJmmJo0olk9oz/1UVdzGJ3Qtb3bhBuTU=",
      "url": "_framework/System.Memory.726r5hplox.wasm"
    },
    {
      "hash": "sha256-KyC3o45L87VxIVFqnoX9ko7KXYbQTowrd6cfgpG1H18=",
      "url": "_framework/System.Net.Http.bootapjmg0.wasm"
    },
    {
      "hash": "sha256-lpuToxoC6gyjBIE2Z0NrXP7Q+Zku/Hml1ND72k+jG48=",
      "url": "_framework/System.Net.Primitives.qk8k4u090q.wasm"
    },
    {
      "hash": "sha256-hKxmxpheuuq8OHla+2xklAkpvQENbX7KmlC9qWRnn+c=",
      "url": "_framework/System.ObjectModel.ssz5r1bbkc.wasm"
    },
    {
      "hash": "sha256-KZAwB+mD2m65w1fx3aJmHMra08FCqXiP3k1kOnPX+Jw=",
      "url": "_framework/System.Private.CoreLib.rbnnu74gjw.wasm"
    },
    {
      "hash": "sha256-8aNQ0OrPMSxx7NERBBM83D9x3pU3PFzw2T60AQ6/RBo=",
      "url": "_framework/System.Private.Uri.d57b3i8vm1.wasm"
    },
    {
      "hash": "sha256-3IoLyXDPZlSSNuf0cCFYH/6pnHsiIz+bg/ptKuGnMiI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4wymnd9fjf.wasm"
    },
    {
      "hash": "sha256-o9TYS1cOs+zSxdLbZRl/3dOSXBTUkZ+VGv4sJ86qi/U=",
      "url": "_framework/System.Runtime.InteropServices.pt770ios6x.wasm"
    },
    {
      "hash": "sha256-7yN4FdsJxJJfgT7yCXB6fXEdtG5E3wX6yCOWhn+Nu2E=",
      "url": "_framework/System.Runtime.f49rxvm37k.wasm"
    },
    {
      "hash": "sha256-HRKS6NZ08uA9tvp6VNdnuMCDT/x623vH7mBCAoJbESU=",
      "url": "_framework/System.Text.Encodings.Web.ptvc6ocoh5.wasm"
    },
    {
      "hash": "sha256-tlluHZ5mD6CGWXYj4rErrzXQac3OPInMuF4XVLh/fig=",
      "url": "_framework/System.Text.Json.iuclyk4cjz.wasm"
    },
    {
      "hash": "sha256-WyGyBXedwaB6IiowNjcSvoVQ2KjKVDsCyToRfVEifQE=",
      "url": "_framework/System.Text.RegularExpressions.bs258ng3dt.wasm"
    },
    {
      "hash": "sha256-DM5iEENhrifGKn33Y7cqRzxC0OtHXYOKO13icwIazj8=",
      "url": "_framework/System.cunp5qiwjj.wasm"
    },
    {
      "hash": "sha256-r6CiXXmQ6qkQ+0OrfISiGlo2VNmzqzLUF6BGIzZArIU=",
      "url": "_framework/TechnicalAnalysis.Candles.bl3iesg8e1.wasm"
    },
    {
      "hash": "sha256-cQWxB/xbXs5wm7l35EcFbbVTKct4l6ftp+UI8eK8Q9A=",
      "url": "_framework/TechnicalAnalysis.Common.18h57u0qcv.wasm"
    },
    {
      "hash": "sha256-sdV9O+r79GVELSQuBM7Yeo0UKSmOYzNcCoVSOZGQk58=",
      "url": "_framework/TechnicalAnalysis.Functions.t1r3urkz7x.wasm"
    },
    {
      "hash": "sha256-6y9WcTJJ7HdoGBMucSh0ZZSgHCtLWN5nTyvwqXjnZMs=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-VSrDABliXym1uaVGf/4XAZdHT7sA5xiMiD/TmJeALDc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-QgAJsJSEDZ9XA0g3PW3EffgXg+ymMp2uRhGnkVsOxQY=",
      "url": "_framework/dotnet.native.aqhezbunpl.wasm"
    },
    {
      "hash": "sha256-HyBzcYNpT2l19+f1bpjNOa1oFoLe3K4JIQ6GsFK5m6I=",
      "url": "_framework/dotnet.native.rtblh4npr3.js"
    },
    {
      "hash": "sha256-gbZjXNFbH7V8lcix+H0TUDJHLeFUA3n3IMu7fLh4D80=",
      "url": "_framework/dotnet.runtime.d1pzlaz2ez.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Y0W2BrXA2W+iMOvac3a+G1GlJoK3RmMpJcIbhemqbGU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LIDaGPQuZu8g1QOOr/UUXNrhLfvw0ZYP6z9cVbjIRyI=",
      "url": "index.html"
    },
    {
      "hash": "sha256-R25UNyCpj4CK8yB/1gtqA38W2M/OqKs3G8nLgGIYMAI=",
      "url": "js/d3-charts.js"
    },
    {
      "hash": "sha256-+O7O1LShC0Z2y7DNaVi8W6Nfh+FHVfz3YNr5m2CP9D0=",
      "url": "manifest.json"
    }
  ]
};
